import { i as __toESM } from "../_runtime.mjs";
import { n as practice } from "./practice-Di5hxtw9.mjs";
import { J as require_react, S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/appointment-form-D4cU3SoO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var reasons = [
	"New patient exam",
	"Preventive / cleaning",
	"Cosmetic consultation",
	"Invisalign consultation",
	"Restorative care",
	"Something else"
];
function AppointmentForm() {
	const [errors, setErrors] = (0, import_react.useState)({});
	const [done, setDone] = (0, import_react.useState)(false);
	function onSubmit(event) {
		event.preventDefault();
		const data = new FormData(event.currentTarget);
		const name = String(data.get("name") ?? "").trim();
		const phone = String(data.get("phone") ?? "").trim();
		const email = String(data.get("email") ?? "").trim();
		const reason = String(data.get("reason") ?? "");
		const next = {};
		if (name.length < 2) next.name = "Please enter your name.";
		if (!/^[0-9()\-\s.+]{7,}$/.test(phone)) next.phone = "Enter a phone number we could call.";
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Enter a valid email address.";
		if (!reason) next.reason = "Choose what you would like to discuss.";
		setErrors(next);
		setDone(Object.keys(next).length === 0);
	}
	if (done) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-sage/40 bg-sage-soft p-6",
		role: "status",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "font-display text-2xl text-forest",
			children: "This form is a demonstration"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 text-ink",
			children: [
				"Nothing was sent to the office, and no appointment was reserved. To request a visit, call",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "font-medium text-forest",
					href: `tel:${practice.phoneTel}`,
					children: practice.phoneDisplay
				}),
				" ",
				"Monday through Friday."
			]
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		noValidate: true,
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Demonstration only. Submitting this form does not contact Dr. Masera’s office or hold a time."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Name",
				name: "name",
				error: errors.name,
				autoComplete: "name"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Phone",
				name: "phone",
				error: errors.phone,
				autoComplete: "tel",
				type: "tel"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Email",
				name: "email",
				error: errors.email,
				autoComplete: "email",
				type: "email"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-sm font-medium",
					htmlFor: "reason",
					children: "What would you like to discuss?"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					id: "reason",
					name: "reason",
					defaultValue: "",
					className: "mt-1 w-full min-h-12 rounded-md border border-line bg-paper px-3",
					"aria-invalid": Boolean(errors.reason),
					"aria-describedby": errors.reason ? "reason-error" : void 0,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						disabled: true,
						children: "Select one"
					}), reasons.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))]
				}),
				errors.reason ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					id: "reason-error",
					className: "mt-1 text-sm text-danger",
					children: errors.reason
				}) : null
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "text-sm font-medium",
				htmlFor: "note",
				children: ["Anything we should know? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-normal text-muted",
					children: "(optional)"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				id: "note",
				name: "note",
				rows: 4,
				className: "mt-1 w-full rounded-md border border-line bg-paper px-3 py-3"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "min-h-12 rounded-full bg-forest px-6 font-medium text-paper hover:bg-ink",
				children: "Preview request"
			})
		]
	});
}
function Field({ label, name, error, type = "text", autoComplete }) {
	const errorId = `${name}-error`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: "text-sm font-medium",
			htmlFor: name,
			children: label
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id: name,
			name,
			type,
			autoComplete,
			"aria-invalid": Boolean(error),
			"aria-describedby": error ? errorId : void 0,
			className: "mt-1 w-full min-h-12 rounded-md border border-line bg-paper px-3"
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			id: errorId,
			className: "mt-1 text-sm text-danger",
			children: error
		}) : null
	] });
}
//#endregion
export { AppointmentForm as t };
