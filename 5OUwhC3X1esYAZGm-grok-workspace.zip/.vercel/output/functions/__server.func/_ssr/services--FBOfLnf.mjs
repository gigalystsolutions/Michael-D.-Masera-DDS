import { r as services } from "./practice-Di5hxtw9.mjs";
import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageIntro } from "./router-CeHjY2Ww.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services--FBOfLnf.js
var import_jsx_runtime = require_jsx_runtime();
var also = [
	"Teeth whitening — Opalescence Go",
	"Periodontics",
	"Oral cancer screening",
	"Root canal therapy and oral surgery, when necessary",
	"Crowns, bridges, and dentures",
	"Tooth-colored fillings"
];
function ServicesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "pb-24 md:pb-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
				eyebrow: "Care",
				title: "Services, described the way the office actually offers them.",
				lede: "Nothing here is a price list or a promise of a result. It is the range of care published by Meyerland Family & Cosmetic Dentistry, written so a new patient can see where to start."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container-page flex flex-wrap gap-2 py-6",
				children: services.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: `#${service.id}`,
					className: "rounded-full border border-line bg-paper px-4 py-2 text-sm no-underline",
					children: service.title
				}, service.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-page space-y-16 pb-20",
				children: [services.map((service, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					id: service.id,
					className: "grid items-center gap-8 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: service.image,
						alt: service.alt,
						className: `aspect-[4/3] w-full rounded-lg object-cover ${index % 2 ? "lg:order-2" : ""}`,
						width: 1200,
						height: 900
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-4xl text-forest",
							children: service.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-muted",
							children: service.body
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							className: "mt-6 inline-flex min-h-11 items-center font-medium text-forest no-underline",
							children: "Ask about this at the office"
						})
					] })]
				}, service.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg bg-paper p-6 md:p-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-3xl text-forest",
						children: "Also part of the practice"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-5 grid gap-3 sm:grid-cols-2",
						children: also.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-t border-line pt-3 text-ink",
							children: item
						}, item))
					})]
				})]
			})
		]
	});
}
//#endregion
export { ServicesPage as component };
