import { n as practice } from "./practice-Di5hxtw9.mjs";
import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageIntro } from "./router-CeHjY2Ww.mjs";
import { t as AppointmentForm } from "./appointment-form-D4cU3SoO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-D_z690uj.js
var import_jsx_runtime = require_jsx_runtime();
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "pb-24 md:pb-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			eyebrow: "Contact",
			title: "Request a visit the way the office actually books them.",
			lede: "Call Monday through Friday. The form beside the phone number is a design demonstration — it validates what you type, then reminds you that nothing was sent."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-page grid gap-10 py-14 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-paper p-6 md:p-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl text-forest",
					children: "Preview an appointment request"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppointmentForm, {})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl text-forest",
					children: "The office"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-6 space-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "eyebrow",
							children: "Phone"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "font-display text-4xl text-forest no-underline",
							href: `tel:${practice.phoneTel}`,
							children: practice.phoneDisplay
						}) })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "eyebrow",
							children: "Fax"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-lg",
							children: practice.faxDisplay
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "eyebrow",
							children: "Address"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [practice.addressLines.join(", "), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-muted",
							children: practice.addressNote
						})] })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "eyebrow",
							children: "Hours"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [practice.hours, ". Exact daily hours are confirmed when you call."] })] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "mt-8 inline-flex min-h-12 items-center rounded-full border border-forest px-5 font-medium text-forest no-underline",
					href: practice.mapsUrl,
					children: "Open in Google Maps"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "mt-3 block text-forest underline-offset-4 hover:underline",
					href: practice.facebook,
					children: "Facebook page"
				})
			] })]
		})]
	});
}
//#endregion
export { ContactPage as component };
