//#region node_modules/.nitro/vite/services/ssr/assets/practice-Di5hxtw9.js
var practice = {
	doctor: "Michael D. Masera, DDS",
	name: "Meyerland Family & Cosmetic Dentistry",
	short: "Masera Dentistry",
	addressLines: ["9660 Hillcroft Street, Suite 110", "Houston, TX 77096"],
	addressNote: "First floor of the Bank of America building",
	phoneDisplay: "713-723-5615",
	phoneTel: "+17137235615",
	faxDisplay: "713-723-3431",
	mapsUrl: "https://www.google.com/maps/search/?api=1&query=Michael+D.+Masera+DDS+9660+Hillcroft+Street+Houston+TX+77096",
	facebook: "https://www.facebook.com/MichaelMaseraDDSHoustonTX",
	formsEn: "https://michaelmaseradds.com/forms/2026_Patient_Forms_MaseraDDS.pdf",
	formsEs: "https://michaelmaseradds.com/forms/CS_Patient_Info_Health_History_Spanish_DrMasera.pdf",
	hours: "Monday through Friday"
};
var services = [
	{
		id: "cosmetic",
		title: "Cosmetic dentistry",
		summary: "Smile-focused care discussed in a complimentary consultation, so you understand the plan before treatment begins.",
		image: "/images/smile.jpg",
		alt: "Natural portrait of an adult with a relaxed smile, used as concept photography",
		body: "Cosmetic care at the practice includes options such as porcelain veneers and teeth whitening with Opalescence Go. Dr. Masera offers complimentary consultations for patients considering cosmetic dentistry, so questions about appearance, timing, and cost can be discussed before any treatment starts."
	},
	{
		id: "invisalign",
		title: "Invisalign",
		summary: "Clear aligner treatment for patients who want to straighten teeth, with a consultation to see whether it fits.",
		image: "/images/aligner.jpg",
		alt: "Clear aligner tray on linen, concept still-life photography",
		body: "Invisalign clear aligners are offered for patients interested in straightening their teeth. A complimentary consultation is available so the doctor can listen to what you want and explain whether aligner treatment is appropriate before anything begins."
	},
	{
		id: "preventive",
		title: "Preventive family care",
		summary: "Exams, cleanings, and everyday care for households across Meyerland and southwest Houston.",
		image: "/images/family.jpg",
		alt: "A parent and child laughing outdoors, concept lifestyle photography",
		body: "Preventive family dentistry is a core part of the practice. A first visit usually includes a thorough examination and records so a practical plan can be made. Appointments are scheduled with an eye toward keeping time away from work and school as reasonable as possible."
	},
	{
		id: "veneers",
		title: "Porcelain veneers",
		summary: "Veneers are discussed as part of cosmetic care, with treatment explained before it begins.",
		image: "/images/mirror.jpg",
		alt: "Hands holding a small mirror near a calm smile, concept photography",
		body: "Porcelain veneers are listed among the practice’s cosmetic services, alongside crowns and tooth-colored restorations. The office’s stated approach is to explain treatment before it begins and to help patients feel at ease with the plan."
	},
	{
		id: "restorative",
		title: "Restorative dentistry",
		summary: "Crowns, bridges, dentures, tooth-colored fillings, and related care when teeth need to be rebuilt.",
		image: "/images/interior.jpg",
		alt: "Quiet consultation room in warm ivory and sage tones, concept interior photography",
		body: "Restorative care includes crowns, bridges, dentures, and tooth-colored fillings. When needed, the practice also provides root canal therapy and removal of teeth, along with periodontal care and oral cancer screening."
	}
];
var faqs = [
	{
		q: "How do I request an appointment?",
		a: "Office visits are by appointment. Call 713-723-5615 Monday through Friday. This demonstration website does not book real appointments."
	},
	{
		q: "What happens at a first visit?",
		a: "A first visit usually includes a thorough examination and records so the office can develop a plan. The team wants to hear your concerns and address them at that appointment."
	},
	{
		q: "Do you offer consultations for cosmetic care or Invisalign?",
		a: "Yes. Dr. Masera offers complimentary consultations for patients considering cosmetic dentistry, Invisalign, or other comprehensive dentistry."
	},
	{
		q: "How does insurance work?",
		a: "The office works with most PPO insurance companies. Staff estimate the patient’s portion and, as a courtesy, send claim forms and wait a reasonable time for the insurer to reimburse the office. The financial commitment remains the patient’s responsibility."
	},
	{
		q: "Which forms of payment are accepted?",
		a: "The practice accepts cash, personal checks, Visa, Mastercard, Discover, and American Express. Healthcare financing through CareCredit is also mentioned on the current patient information page."
	},
	{
		q: "Can I complete forms before I arrive?",
		a: "Yes. New-patient forms are available as PDFs in English and Spanish. Print and complete them before your visit, or call the office if you need them sent or faxed."
	},
	{
		q: "What if I have a dental emergency?",
		a: "The office allows time for emergencies when patients have special needs. Call 713-723-5615. If you cannot keep an appointment, the practice asks that you notify them as soon as possible."
	},
	{
		q: "Will treatment be explained before it starts?",
		a: "Yes. The practice states that all treatment is explained before it begins, and that helping patients feel at ease is a priority. This site does not quote fees, because costs depend on the plan discussed in the office."
	}
];
//#endregion
export { practice as n, services as r, faqs as t };
