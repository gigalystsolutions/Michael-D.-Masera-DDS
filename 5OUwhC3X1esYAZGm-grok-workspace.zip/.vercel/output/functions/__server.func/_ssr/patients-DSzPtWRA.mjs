import { n as practice, t as faqs } from "./practice-Di5hxtw9.mjs";
import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageIntro } from "./router-CeHjY2Ww.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/patients-DSzPtWRA.js
var import_jsx_runtime = require_jsx_runtime();
function PatientsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "pb-24 md:pb-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
				eyebrow: "Patients",
				title: "Everything to gather before you walk in.",
				lede: "Appointments are reserved by phone. Forms can be printed ahead of time. Insurance questions are handled in the office, where staff can look at your actual plan."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "container-page grid gap-5 py-14 md:grid-cols-3",
				children: [
					["Insurance", "The team works with most PPO plans, completes claim forms, and waits a reasonable time for payment. Your portion is estimated at the visit. The balance remains your responsibility."],
					["Payment", "Cash, personal checks, Visa, Mastercard, Discover, and American Express are accepted. CareCredit is also listed for healthcare financing."],
					["Courtesy", "If you cannot keep an appointment, call as soon as you can so the time can be offered to someone else. The office tries to stay on time and asks the same in return."]
				].map(([title, text]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-lg border border-line bg-paper p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl text-forest",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: text
					})]
				}, title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-paper py-14",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-page grid gap-6 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "rounded-lg border border-line p-6 no-underline",
						href: practice.formsEn,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "English"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 text-3xl text-forest",
								children: "2026 patient forms"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-muted",
								children: "Download, print, and bring the completed packet to your visit."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "rounded-lg border border-line p-6 no-underline",
						href: practice.formsEs,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "Español"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 text-3xl text-forest",
								children: "Formularios para pacientes"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-muted",
								children: "Formularios en español publicados por el consultorio."
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "container-page py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-4xl text-forest",
					children: "Questions people ask first"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 divide-y divide-line border-y border-line",
					children: faqs.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
						className: "group py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
							className: "cursor-pointer list-none font-medium text-ink marker:content-none",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center justify-between gap-4",
								children: [item.q, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sage group-open:rotate-45",
									"aria-hidden": true,
									children: "+"
								})]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-3xl text-muted",
							children: item.a
						})]
					}, item.q))
				})]
			})
		]
	});
}
//#endregion
export { PatientsPage as component };
