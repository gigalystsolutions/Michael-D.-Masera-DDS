import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageIntro } from "./router-CeHjY2Ww.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-ihgl-RmY.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "pb-24 md:pb-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			eyebrow: "Privacy",
			title: "This concept does not keep what you type.",
			lede: "The appointment form runs only in your browser. It checks that the fields look complete, then stops. It does not email the office, store a record, or confirm a time."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "container-page max-w-3xl space-y-4 py-12 text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A live website for Michael D. Masera, DDS should publish the practice’s own notice about health information, website analytics, and how appointment requests are handled. That policy is not invented here." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Patient forms linked from this demo open the PDFs already published on the practice’s current website. Those files are hosted by the practice, not by this concept." })]
		})]
	});
}
//#endregion
export { PrivacyPage as component };
