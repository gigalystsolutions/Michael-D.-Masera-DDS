import { n as practice, r as services } from "./practice-Di5hxtw9.mjs";
import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as CalendarCheck, i as ShieldCheck, l as ArrowRight, r as Sparkles, s as Clock3 } from "../_libs/lucide-react.mjs";
import { t as AppointmentForm } from "./appointment-form-D4cU3SoO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-J2umx2cu.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "pb-24 md:pb-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-page grid items-center gap-10 py-12 lg:grid-cols-12 lg:py-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:col-span-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "Meyerland · Houston"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-4 text-5xl text-forest sm:text-6xl lg:text-7xl",
								children: "Dentistry that takes the worry out of the visit."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 max-w-xl text-lg text-muted",
								children: "Michael D. Masera, DDS, offers family and cosmetic care on Hillcroft Street — with treatment explained before it begins, and time set aside to hear what you actually want."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex flex-col gap-3 sm:flex-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/contact",
									className: "inline-flex min-h-12 items-center justify-center rounded-full bg-forest px-6 font-medium text-paper no-underline hover:bg-ink",
									children: "Request an Appointment"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: `tel:${practice.phoneTel}`,
									className: "inline-flex min-h-12 items-center justify-center rounded-full border border-forest px-6 font-medium text-forest no-underline hover:bg-sage-soft",
									children: "Call our office"
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:col-span-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/images/hero.jpg",
								alt: "Concept photograph of a calm, natural smile in warm light",
								className: "aspect-[4/5] w-full rounded-lg object-cover sm:aspect-[5/4] lg:aspect-[4/5] lg:max-h-[680px]",
								width: 1200,
								height: 1600
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
								className: "absolute bottom-4 left-4 right-4 rounded-md bg-paper/92 p-4 text-sm text-ink shadow-sm sm:left-auto sm:max-w-xs",
								children: "Over 30 years in practice. Over 20 years at this Hillcroft location."
							})]
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				"aria-label": "Practice facts",
				className: "border-y border-line bg-ivory",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "container-page grid gap-6 py-8 sm:grid-cols-2 lg:grid-cols-4",
					children: [
						{
							icon: Clock3,
							title: "Established care",
							text: "More than 30 years in practice, and more than 20 at Hillcroft."
						},
						{
							icon: Sparkles,
							title: "Consultations",
							text: "Complimentary visits for cosmetic care, Invisalign, or comprehensive dentistry."
						},
						{
							icon: ShieldCheck,
							title: "Most PPO plans",
							text: "The office estimates your portion and files claims as a courtesy."
						},
						{
							icon: CalendarCheck,
							title: practice.hours,
							text: "Call ahead so a time can be reserved for you. Emergencies are worked in when possible."
						}
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
							className: "mt-1 size-5 shrink-0 text-sage",
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium text-forest",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: item.text
						})] })]
					}, item.title))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "container-page grid items-center gap-10 py-16 lg:grid-cols-2 lg:py-24",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/family.jpg",
					alt: "Concept photograph of a parent and child sharing a laugh outdoors",
					className: "aspect-[4/3] w-full rounded-lg object-cover",
					width: 1600,
					height: 1200
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "Welcome"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 text-4xl text-forest md:text-5xl",
						children: "A familiar office, with room to ask the real questions."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 space-y-4 text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Many people arrive wondering whether it will hurt, how long it will take, whether the staff will be kind, and what it will cost. Dr. Masera’s office is built around answering those questions plainly." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "He believes in quality dentistry and affordable fees, and he wants patients to feel at ease. All treatment is explained before it begins. From the first appointment, the goal is an efficient plan that respects time away from work and school." })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/practice",
						className: "mt-6 inline-flex min-h-11 items-center gap-2 font-medium text-forest no-underline",
						children: ["Meet the practice ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
							className: "size-4",
							"aria-hidden": true
						})]
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-paper py-16 lg:py-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-page",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "Care"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 text-4xl text-forest md:text-5xl",
							children: "A full practice, explained simply."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/services",
							className: "inline-flex min-h-11 items-center font-medium text-forest no-underline",
							children: "All services"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-10 grid gap-5 md:grid-cols-2",
						children: services.slice(0, 4).map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/services",
							hash: service.id,
							className: "group grid overflow-hidden rounded-lg border border-line bg-ivory no-underline sm:grid-cols-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: service.image,
								alt: "",
								className: "aspect-[4/3] h-full w-full object-cover sm:col-span-2 sm:aspect-auto"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex flex-col justify-center p-5 sm:col-span-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-2xl text-forest",
										children: service.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-2 text-sm text-muted",
										children: service.summary
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-4 inline-flex items-center gap-2 text-sm font-medium text-forest",
										children: ["Read more ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
											className: "size-4 transition-transform group-hover:translate-x-1",
											"aria-hidden": true
										})]
									})
								]
							})]
						}) }, service.id))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "container-page grid gap-10 py-16 lg:grid-cols-12 lg:py-24",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "The dentist"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 text-4xl text-forest md:text-5xl",
							children: "Dr. Michael D. Masera"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-muted",
							children: "Dr. Masera has been in practice for over 30 years and at 9660 Hillcroft for over 20 years. Patients looking at cosmetic dentistry, Invisalign, or broader treatment can start with a complimentary consultation."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-muted",
							children: "A formal portrait of Dr. Masera is reserved for approved photography. This concept does not use a stand-in likeness."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/practice",
							className: "mt-6 inline-flex min-h-12 items-center rounded-full border border-forest px-5 font-medium text-forest no-underline",
							children: "About the practice"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-4 sm:grid-cols-2 lg:col-span-7",
					children: [
						["Listen first", "The first appointment is for understanding your concerns, not rushing a plan."],
						["Explain before", "Treatment is described before it begins, including what you can expect."],
						["Keep it practical", "Appointment times are planned to limit time away from work and school."],
						["Stay local", "The office is on the first floor of the Bank of America building at Hillcroft and the surrounding Meyerland area."]
					].map(([title, text]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-lg border border-line bg-paper p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-2xl text-forest",
							children: title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: text
						})]
					}, title))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-sage-soft/70 py-16",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-page grid gap-8 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "Patient stories"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 text-4xl text-forest",
							children: "Reviews, when the practice approves them."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-muted",
							children: "This concept does not invent testimonials or star ratings. When Dr. Masera’s office selects reviews it is comfortable publishing, they belong here — with names and wording left exactly as written."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "mt-6 inline-flex min-h-11 items-center font-medium text-forest",
							href: practice.mapsUrl,
							children: "Find the office on Google Maps"
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-dashed border-sage bg-paper p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "Reserved"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 font-display text-3xl text-forest",
								children: "“ ”"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-muted",
								children: "Approved patient comments will be placed in this panel. Until then, the honest next step is a phone call."
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "container-page grid gap-8 py-16 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "Before you come in"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 text-4xl text-forest",
							children: "Forms, insurance, and the first visit."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-muted",
							children: "Print the new-patient forms, or call if you would rather have them sent. The office works with most PPO plans and will estimate your portion."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/patients",
							className: "mt-5 inline-flex min-h-11 items-center font-medium text-forest no-underline",
							children: "Patient information"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "grid gap-3 lg:col-span-3",
					children: [[["English patient forms", practice.formsEn], ["Formularios en español", practice.formsEs]].map(([label, href]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "flex min-h-16 items-center justify-between rounded-lg border border-line bg-paper px-5 no-underline",
						href,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-forest",
							children: label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: "PDF"
						})]
					}) }, label)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/contact",
						className: "flex min-h-16 items-center justify-between rounded-lg border border-line bg-paper px-5 no-underline",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-forest",
							children: "Questions before you book"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: "Contact"
						})]
					}) })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-forest text-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-page grid items-center gap-8 py-16 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-4xl md:text-5xl",
							children: "When you are ready, call. We would like to be your dentist."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-md text-paper/80",
							children: "The request form on this concept site is only a preview. The office still schedules by phone, Monday through Friday."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "mt-6 inline-flex font-display text-4xl text-paper no-underline",
							href: `tel:${practice.phoneTel}`,
							children: practice.phoneDisplay
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-lg bg-paper p-6 text-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppointmentForm, {})
					})]
				})
			})
		]
	});
}
//#endregion
export { Home as component };
