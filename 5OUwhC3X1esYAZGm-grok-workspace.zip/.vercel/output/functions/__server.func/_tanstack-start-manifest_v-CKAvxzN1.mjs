//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CKAvxzN1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/contact",
			"/patients",
			"/practice",
			"/privacy",
			"/services"
		],
		preloads: ["/assets/index-_p_06rNo.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-_p_06rNo.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-7LmFY6HR.js", "/assets/appointment-form-EvjK1TJL.js"]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-DG8dqGJY.js", "/assets/appointment-form-EvjK1TJL.js"]
	},
	"/patients": {
		filePath: "/workspace/src/routes/patients.tsx",
		children: void 0,
		preloads: ["/assets/patients-JOYJnaFH.js"]
	},
	"/practice": {
		filePath: "/workspace/src/routes/practice.tsx",
		children: void 0,
		preloads: ["/assets/practice-0IUguB8m.js"]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-BibQ7dhA.js"]
	},
	"/services": {
		filePath: "/workspace/src/routes/services.tsx",
		children: void 0,
		preloads: ["/assets/services-BMK0Kf_x.js"]
	}
} });
//#endregion
export { tsrStartManifest };
