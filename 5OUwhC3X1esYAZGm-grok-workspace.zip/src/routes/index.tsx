import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CalendarCheck, ShieldCheck, Clock3, Sparkles } from "lucide-react";
import { AppointmentForm } from "@/components/appointment-form";
import { practice, services } from "@/lib/practice";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Michael D. Masera, DDS | Meyerland Family & Cosmetic Dentistry" },
      {
        name: "description",
        content:
          "Dr. Michael D. Masera has practiced dentistry for over 30 years and has been at the Hillcroft location for over 20 years. Family, cosmetic, and Invisalign care in Meyerland, Houston.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <main className="pb-24 md:pb-0">
      <section className="bg-paper">
        <div className="container-page grid items-center gap-10 py-12 lg:grid-cols-12 lg:py-20">
          <div className="lg:col-span-6">
            <p className="eyebrow">Meyerland · Houston</p>
            <h1 className="mt-4 text-5xl text-forest sm:text-6xl lg:text-7xl">
              Dentistry that takes the worry out of the visit.
            </h1>
            <p className="mt-6 max-w-xl text-lg text-muted">
              Michael D. Masera, DDS, offers family and cosmetic care on Hillcroft Street — with treatment explained before it begins, and time set aside to hear what you actually want.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link
                to="/contact"
                className="inline-flex min-h-12 items-center justify-center rounded-full bg-forest px-6 font-medium text-paper no-underline hover:bg-ink"
              >
                Request an Appointment
              </Link>
              <a
                href={`tel:${practice.phoneTel}`}
                className="inline-flex min-h-12 items-center justify-center rounded-full border border-forest px-6 font-medium text-forest no-underline hover:bg-sage-soft"
              >
                Call our office
              </a>
            </div>
          </div>
          <div className="lg:col-span-6">
            <figure className="relative">
              <img
                src="/images/hero.jpg"
                alt="Concept photograph of a calm, natural smile in warm light"
                className="aspect-[4/5] w-full rounded-lg object-cover sm:aspect-[5/4] lg:aspect-[4/5] lg:max-h-[680px]"
                width={1200}
                height={1600}
              />
              <figcaption className="absolute bottom-4 left-4 right-4 rounded-md bg-paper/92 p-4 text-sm text-ink shadow-sm sm:left-auto sm:max-w-xs">
                Over 30 years in practice. Over 20 years at this Hillcroft location.
              </figcaption>
            </figure>
          </div>
        </div>
      </section>

      <section aria-label="Practice facts" className="border-y border-line bg-ivory">
        <ul className="container-page grid gap-6 py-8 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: Clock3, title: "Established care", text: "More than 30 years in practice, and more than 20 at Hillcroft." },
            { icon: Sparkles, title: "Consultations", text: "Complimentary visits for cosmetic care, Invisalign, or comprehensive dentistry." },
            { icon: ShieldCheck, title: "Most PPO plans", text: "The office estimates your portion and files claims as a courtesy." },
            { icon: CalendarCheck, title: practice.hours, text: "Call ahead so a time can be reserved for you. Emergencies are worked in when possible." },
          ].map((item) => (
            <li key={item.title} className="flex gap-3">
              <item.icon className="mt-1 size-5 shrink-0 text-sage" aria-hidden />
              <div>
                <p className="font-medium text-forest">{item.title}</p>
                <p className="text-sm text-muted">{item.text}</p>
              </div>
            </li>
          ))}
        </ul>
      </section>

      <section className="container-page grid items-center gap-10 py-16 lg:grid-cols-2 lg:py-24">
        <img
          src="/images/family.jpg"
          alt="Concept photograph of a parent and child sharing a laugh outdoors"
          className="aspect-[4/3] w-full rounded-lg object-cover"
          width={1600}
          height={1200}
        />
        <div>
          <p className="eyebrow">Welcome</p>
          <h2 className="mt-3 text-4xl text-forest md:text-5xl">A familiar office, with room to ask the real questions.</h2>
          <div className="mt-5 space-y-4 text-muted">
            <p>
              Many people arrive wondering whether it will hurt, how long it will take, whether the staff will be kind, and what it will cost. Dr. Masera’s office is built around answering those questions plainly.
            </p>
            <p>
              He believes in quality dentistry and affordable fees, and he wants patients to feel at ease. All treatment is explained before it begins. From the first appointment, the goal is an efficient plan that respects time away from work and school.
            </p>
          </div>
          <Link to="/practice" className="mt-6 inline-flex min-h-11 items-center gap-2 font-medium text-forest no-underline">
            Meet the practice <ArrowRight className="size-4" aria-hidden />
          </Link>
        </div>
      </section>

      <section className="bg-paper py-16 lg:py-24">
        <div className="container-page">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow">Care</p>
              <h2 className="mt-3 text-4xl text-forest md:text-5xl">A full practice, explained simply.</h2>
            </div>
            <Link to="/services" className="inline-flex min-h-11 items-center font-medium text-forest no-underline">
              All services
            </Link>
          </div>
          <ul className="mt-10 grid gap-5 md:grid-cols-2">
            {services.slice(0, 4).map((service) => (
              <li key={service.id}>
                <Link
                  to="/services"
                  hash={service.id}
                  className="group grid overflow-hidden rounded-lg border border-line bg-ivory no-underline sm:grid-cols-5"
                >
                  <img
                    src={service.image}
                    alt=""
                    className="aspect-[4/3] h-full w-full object-cover sm:col-span-2 sm:aspect-auto"
                  />
                  <span className="flex flex-col justify-center p-5 sm:col-span-3">
                    <span className="font-display text-2xl text-forest">{service.title}</span>
                    <span className="mt-2 text-sm text-muted">{service.summary}</span>
                    <span className="mt-4 inline-flex items-center gap-2 text-sm font-medium text-forest">
                      Read more <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden />
                    </span>
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="container-page grid gap-10 py-16 lg:grid-cols-12 lg:py-24">
        <div className="lg:col-span-5">
          <p className="eyebrow">The dentist</p>
          <h2 className="mt-3 text-4xl text-forest md:text-5xl">Dr. Michael D. Masera</h2>
          <p className="mt-5 text-muted">
            Dr. Masera has been in practice for over 30 years and at 9660 Hillcroft for over 20 years. Patients looking at cosmetic dentistry, Invisalign, or broader treatment can start with a complimentary consultation.
          </p>
          <p className="mt-4 text-sm text-muted">
            A formal portrait of Dr. Masera is reserved for approved photography. This concept does not use a stand-in likeness.
          </p>
          <Link to="/practice" className="mt-6 inline-flex min-h-12 items-center rounded-full border border-forest px-5 font-medium text-forest no-underline">
            About the practice
          </Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:col-span-7">
          {[
            ["Listen first", "The first appointment is for understanding your concerns, not rushing a plan."],
            ["Explain before", "Treatment is described before it begins, including what you can expect."],
            ["Keep it practical", "Appointment times are planned to limit time away from work and school."],
            ["Stay local", "The office is on the first floor of the Bank of America building at Hillcroft and the surrounding Meyerland area."],
          ].map(([title, text]) => (
            <article key={title} className="rounded-lg border border-line bg-paper p-5">
              <h3 className="font-display text-2xl text-forest">{title}</h3>
              <p className="mt-2 text-sm text-muted">{text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="bg-sage-soft/70 py-16">
        <div className="container-page grid gap-8 lg:grid-cols-2">
          <div>
            <p className="eyebrow">Patient stories</p>
            <h2 className="mt-3 text-4xl text-forest">Reviews, when the practice approves them.</h2>
            <p className="mt-4 text-muted">
              This concept does not invent testimonials or star ratings. When Dr. Masera’s office selects reviews it is comfortable publishing, they belong here — with names and wording left exactly as written.
            </p>
            <a className="mt-6 inline-flex min-h-11 items-center font-medium text-forest" href={practice.mapsUrl}>
              Find the office on Google Maps
            </a>
          </div>
          <div className="rounded-lg border border-dashed border-sage bg-paper p-6">
            <p className="eyebrow">Reserved</p>
            <p className="mt-3 font-display text-3xl text-forest">“ ”</p>
            <p className="mt-2 text-muted">
              Approved patient comments will be placed in this panel. Until then, the honest next step is a phone call.
            </p>
          </div>
        </div>
      </section>

      <section className="container-page grid gap-8 py-16 lg:grid-cols-5">
        <div className="lg:col-span-2">
          <p className="eyebrow">Before you come in</p>
          <h2 className="mt-3 text-4xl text-forest">Forms, insurance, and the first visit.</h2>
          <p className="mt-4 text-muted">
            Print the new-patient forms, or call if you would rather have them sent. The office works with most PPO plans and will estimate your portion.
          </p>
          <Link to="/patients" className="mt-5 inline-flex min-h-11 items-center font-medium text-forest no-underline">
            Patient information
          </Link>
        </div>
        <ul className="grid gap-3 lg:col-span-3">
          {[
            ["English patient forms", practice.formsEn],
            ["Formularios en español", practice.formsEs],
          ].map(([label, href]) => (
            <li key={label}>
              <a className="flex min-h-16 items-center justify-between rounded-lg border border-line bg-paper px-5 no-underline" href={href}>
                <span className="font-medium text-forest">{label}</span>
                <span className="text-sm text-muted">PDF</span>
              </a>
            </li>
          ))}
          <li>
            <Link to="/contact" className="flex min-h-16 items-center justify-between rounded-lg border border-line bg-paper px-5 no-underline">
              <span className="font-medium text-forest">Questions before you book</span>
              <span className="text-sm text-muted">Contact</span>
            </Link>
          </li>
        </ul>
      </section>

      <section className="bg-forest text-paper">
        <div className="container-page grid items-center gap-8 py-16 lg:grid-cols-2">
          <div>
            <h2 className="text-4xl md:text-5xl">When you are ready, call. We would like to be your dentist.</h2>
            <p className="mt-4 max-w-md text-paper/80">
              The request form on this concept site is only a preview. The office still schedules by phone, Monday through Friday.
            </p>
            <a className="mt-6 inline-flex font-display text-4xl text-paper no-underline" href={`tel:${practice.phoneTel}`}>
              {practice.phoneDisplay}
            </a>
          </div>
          <div className="rounded-lg bg-paper p-6 text-ink">
            <AppointmentForm />
          </div>
        </div>
      </section>
    </main>
  );
}
