import { createFileRoute } from "@tanstack/react-router";
import { PageIntro } from "@/components/site-chrome";
import { faqs, practice } from "@/lib/practice";

export const Route = createFileRoute("/patients")({
  head: () => ({
    meta: [
      { title: "Patient information | Michael D. Masera, DDS" },
      {
        name: "description",
        content:
          "New patient forms, PPO insurance, payment options, and answers about first visits at Michael D. Masera, DDS in Houston.",
      },
    ],
  }),
  component: PatientsPage,
});

function PatientsPage() {
  return (
    <main className="pb-24 md:pb-0">
      <PageIntro
        eyebrow="Patients"
        title="Everything to gather before you walk in."
        lede="Appointments are reserved by phone. Forms can be printed ahead of time. Insurance questions are handled in the office, where staff can look at your actual plan."
      />
      <section className="container-page grid gap-5 py-14 md:grid-cols-3">
        {[
          ["Insurance", "The team works with most PPO plans, completes claim forms, and waits a reasonable time for payment. Your portion is estimated at the visit. The balance remains your responsibility."],
          ["Payment", "Cash, personal checks, Visa, Mastercard, Discover, and American Express are accepted. CareCredit is also listed for healthcare financing."],
          ["Courtesy", "If you cannot keep an appointment, call as soon as you can so the time can be offered to someone else. The office tries to stay on time and asks the same in return."],
        ].map(([title, text]) => (
          <article key={title} className="rounded-lg border border-line bg-paper p-6">
            <h2 className="text-2xl text-forest">{title}</h2>
            <p className="mt-3 text-sm text-muted">{text}</p>
          </article>
        ))}
      </section>
      <section className="bg-paper py-14">
        <div className="container-page grid gap-6 md:grid-cols-2">
          <a className="rounded-lg border border-line p-6 no-underline" href={practice.formsEn}>
            <p className="eyebrow">English</p>
            <h2 className="mt-2 text-3xl text-forest">2026 patient forms</h2>
            <p className="mt-2 text-muted">Download, print, and bring the completed packet to your visit.</p>
          </a>
          <a className="rounded-lg border border-line p-6 no-underline" href={practice.formsEs}>
            <p className="eyebrow">Español</p>
            <h2 className="mt-2 text-3xl text-forest">Formularios para pacientes</h2>
            <p className="mt-2 text-muted">Formularios en español publicados por el consultorio.</p>
          </a>
        </div>
      </section>
      <section className="container-page py-16">
        <h2 className="text-4xl text-forest">Questions people ask first</h2>
        <div className="mt-8 divide-y divide-line border-y border-line">
          {faqs.map((item) => (
            <details key={item.q} className="group py-4">
              <summary className="cursor-pointer list-none font-medium text-ink marker:content-none">
                <span className="flex items-center justify-between gap-4">
                  {item.q}
                  <span className="text-sage group-open:rotate-45" aria-hidden>
                    +
                  </span>
                </span>
              </summary>
              <p className="mt-3 max-w-3xl text-muted">{item.a}</p>
            </details>
          ))}
        </div>
      </section>
    </main>
  );
}
