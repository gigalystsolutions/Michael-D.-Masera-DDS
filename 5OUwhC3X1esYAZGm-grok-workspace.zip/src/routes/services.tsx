import { createFileRoute, Link } from "@tanstack/react-router";
import { PageIntro } from "@/components/site-chrome";
import { services } from "@/lib/practice";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Dental services | Michael D. Masera, DDS" },
      {
        name: "description",
        content:
          "Invisalign, cosmetic dentistry, veneers, whitening, preventive family care, periodontics, and restorative dentistry with Dr. Michael D. Masera in Meyerland, Houston.",
      },
    ],
  }),
  component: ServicesPage,
});

const also = [
  "Teeth whitening — Opalescence Go",
  "Periodontics",
  "Oral cancer screening",
  "Root canal therapy and oral surgery, when necessary",
  "Crowns, bridges, and dentures",
  "Tooth-colored fillings",
];

function ServicesPage() {
  return (
    <main className="pb-24 md:pb-0">
      <PageIntro
        eyebrow="Care"
        title="Services, described the way the office actually offers them."
        lede="Nothing here is a price list or a promise of a result. It is the range of care published by Meyerland Family & Cosmetic Dentistry, written so a new patient can see where to start."
      />
      <div className="container-page flex flex-wrap gap-2 py-6">
        {services.map((service) => (
          <a key={service.id} href={`#${service.id}`} className="rounded-full border border-line bg-paper px-4 py-2 text-sm no-underline">
            {service.title}
          </a>
        ))}
      </div>
      <div className="container-page space-y-16 pb-20">
        {services.map((service, index) => (
          <article id={service.id} key={service.id} className="grid items-center gap-8 lg:grid-cols-2">
            <img
              src={service.image}
              alt={service.alt}
              className={`aspect-[4/3] w-full rounded-lg object-cover ${index % 2 ? "lg:order-2" : ""}`}
              width={1200}
              height={900}
            />
            <div>
              <h2 className="text-4xl text-forest">{service.title}</h2>
              <p className="mt-4 text-muted">{service.body}</p>
              <Link to="/contact" className="mt-6 inline-flex min-h-11 items-center font-medium text-forest no-underline">
                Ask about this at the office
              </Link>
            </div>
          </article>
        ))}
        <section className="rounded-lg bg-paper p-6 md:p-10">
          <h2 className="text-3xl text-forest">Also part of the practice</h2>
          <ul className="mt-5 grid gap-3 sm:grid-cols-2">
            {also.map((item) => (
              <li key={item} className="border-t border-line pt-3 text-ink">
                {item}
              </li>
            ))}
          </ul>
        </section>
      </div>
    </main>
  );
}
