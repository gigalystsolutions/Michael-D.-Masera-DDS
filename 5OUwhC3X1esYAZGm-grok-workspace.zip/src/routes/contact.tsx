import { createFileRoute } from "@tanstack/react-router";
import { AppointmentForm } from "@/components/appointment-form";
import { PageIntro } from "@/components/site-chrome";
import { practice } from "@/lib/practice";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact & appointment request | Michael D. Masera, DDS" },
      {
        name: "description",
        content:
          "Call Michael D. Masera, DDS at 713-723-5615. The office is at 9660 Hillcroft Street, Suite 110, Houston, TX 77096.",
      },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <main className="pb-24 md:pb-0">
      <PageIntro
        eyebrow="Contact"
        title="Request a visit the way the office actually books them."
        lede="Call Monday through Friday. The form beside the phone number is a design demonstration — it validates what you type, then reminds you that nothing was sent."
      />
      <section className="container-page grid gap-10 py-14 lg:grid-cols-2">
        <div className="rounded-lg bg-paper p-6 md:p-8">
          <h2 className="text-3xl text-forest">Preview an appointment request</h2>
          <div className="mt-6">
            <AppointmentForm />
          </div>
        </div>
        <div>
          <h2 className="text-3xl text-forest">The office</h2>
          <dl className="mt-6 space-y-5">
            <div>
              <dt className="eyebrow">Phone</dt>
              <dd>
                <a className="font-display text-4xl text-forest no-underline" href={`tel:${practice.phoneTel}`}>
                  {practice.phoneDisplay}
                </a>
              </dd>
            </div>
            <div>
              <dt className="eyebrow">Fax</dt>
              <dd className="text-lg">{practice.faxDisplay}</dd>
            </div>
            <div>
              <dt className="eyebrow">Address</dt>
              <dd>
                {practice.addressLines.join(", ")}
                <span className="mt-1 block text-muted">{practice.addressNote}</span>
              </dd>
            </div>
            <div>
              <dt className="eyebrow">Hours</dt>
              <dd>{practice.hours}. Exact daily hours are confirmed when you call.</dd>
            </div>
          </dl>
          <a
            className="mt-8 inline-flex min-h-12 items-center rounded-full border border-forest px-5 font-medium text-forest no-underline"
            href={practice.mapsUrl}
          >
            Open in Google Maps
          </a>
          <a className="mt-3 block text-forest underline-offset-4 hover:underline" href={practice.facebook}>
            Facebook page
          </a>
        </div>
      </section>
    </main>
  );
}
