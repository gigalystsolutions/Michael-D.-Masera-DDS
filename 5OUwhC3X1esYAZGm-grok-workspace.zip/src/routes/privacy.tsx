import { createFileRoute } from "@tanstack/react-router";
import { PageIntro } from "@/components/site-chrome";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy note | Michael D. Masera, DDS concept" },
      {
        name: "description",
        content: "This redesign demonstration does not collect or store appointment requests.",
      },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <main className="pb-24 md:pb-0">
      <PageIntro
        eyebrow="Privacy"
        title="This concept does not keep what you type."
        lede="The appointment form runs only in your browser. It checks that the fields look complete, then stops. It does not email the office, store a record, or confirm a time."
      />
      <article className="container-page max-w-3xl space-y-4 py-12 text-muted">
        <p>
          A live website for Michael D. Masera, DDS should publish the practice’s own notice about health information, website analytics, and how appointment requests are handled. That policy is not invented here.
        </p>
        <p>
          Patient forms linked from this demo open the PDFs already published on the practice’s current website. Those files are hosted by the practice, not by this concept.
        </p>
      </article>
    </main>
  );
}
