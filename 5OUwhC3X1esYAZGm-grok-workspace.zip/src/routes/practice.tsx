import { createFileRoute, Link } from "@tanstack/react-router";
import { PageIntro } from "@/components/site-chrome";
import { practice } from "@/lib/practice";

export const Route = createFileRoute("/practice")({
  head: () => ({
    meta: [
      { title: "The practice | Michael D. Masera, DDS" },
      {
        name: "description",
        content:
          "Dr. Michael D. Masera has practiced for over 30 years and has cared for patients at 9660 Hillcroft Street in Houston for over 20 years.",
      },
    ],
  }),
  component: PracticePage,
});

function PracticePage() {
  return (
    <main className="pb-24 md:pb-0">
      <PageIntro
        eyebrow="The practice"
        title="Quality dentistry, explained before it begins."
        lede="Dr. Masera has been in practice for over 30 years and at the Hillcroft location for over 20 years. The office’s aim is straightforward: patients should feel at ease, understand the plan, and spend as little extra time away from work and school as possible."
      />
      <section className="container-page grid gap-10 py-16 lg:grid-cols-12">
        <div className="lg:col-span-7">
          <h2 className="text-3xl text-forest">What a new patient can expect</h2>
          <ol className="mt-6 space-y-6">
            {[
              ["Call and reserve a time", "Visits are by appointment so the schedule can be held for you. If something urgent comes up, the office makes an effort to see patients with special needs."],
              ["Bring completed forms", "New-patient paperwork is available in English and Spanish. Filling it out ahead of time leaves more of the visit for the exam."],
              ["Examination and records", "The first visit usually includes a thorough examination and records, so a plan can be built around what you came in for."],
              ["A conversation about the plan", "Concerns about comfort, time, and cost are welcome. Cosmetic dentistry, Invisalign, and comprehensive care can begin with a complimentary consultation."],
              ["Insurance estimated up front", "For most PPO plans, the office estimates your portion, files the claim, and waits a reasonable time for reimbursement. You remain responsible for the fee."],
            ].map(([title, text], index) => (
              <li key={title} className="grid grid-cols-[auto_1fr] gap-4">
                <span className="font-display text-3xl text-sage" aria-hidden>
                  0{index + 1}
                </span>
                <div>
                  <h3 className="text-2xl text-forest">{title}</h3>
                  <p className="mt-1 text-muted">{text}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
        <aside className="lg:col-span-5">
          <div className="overflow-hidden rounded-lg bg-forest text-paper">
            <img
              src="/images/interior.jpg"
              alt="Concept photograph of a quiet consultation room. Not a photograph of the Hillcroft office."
              className="aspect-[16/10] w-full object-cover"
            />
            <div className="p-6">
              <p className="eyebrow text-sage-soft">Photography note</p>
              <p className="mt-3">
                Interior and smile images on this concept are atmosphere photography. They are not pictures of Dr. Masera, the staff, or the Bank of America building suite.
              </p>
              <p className="mt-4 text-sm text-paper/75">
                {practice.addressLines.join(", ")}
                <br />
                {practice.addressNote}
              </p>
              <a className="mt-4 inline-flex min-h-11 items-center font-medium" href={`tel:${practice.phoneTel}`}>
                {practice.phoneDisplay}
              </a>
            </div>
          </div>
        </aside>
      </section>
      <section className="border-t border-line bg-paper">
        <div className="container-page flex flex-col items-start gap-4 py-14 md:flex-row md:items-center md:justify-between">
          <h2 className="max-w-xl text-3xl text-forest">The team page on the current site introduces the people you will meet. This concept keeps that introduction for approved photos.</h2>
          <Link to="/contact" className="inline-flex min-h-12 items-center rounded-full bg-forest px-6 text-paper no-underline">
            Contact the office
          </Link>
        </div>
      </section>
    </main>
  );
}
