import { useState, type FormEvent } from "react";
import { practice } from "@/lib/practice";

type Errors = Partial<Record<"name" | "phone" | "email" | "reason", string>>;

const reasons = [
  "New patient exam",
  "Preventive / cleaning",
  "Cosmetic consultation",
  "Invisalign consultation",
  "Restorative care",
  "Something else",
];

export function AppointmentForm() {
  const [errors, setErrors] = useState<Errors>({});
  const [done, setDone] = useState(false);

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const name = String(data.get("name") ?? "").trim();
    const phone = String(data.get("phone") ?? "").trim();
    const email = String(data.get("email") ?? "").trim();
    const reason = String(data.get("reason") ?? "");
    const next: Errors = {};
    if (name.length < 2) next.name = "Please enter your name.";
    if (!/^[0-9()\-\s.+]{7,}$/.test(phone)) next.phone = "Enter a phone number we could call.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Enter a valid email address.";
    if (!reason) next.reason = "Choose what you would like to discuss.";
    setErrors(next);
    setDone(Object.keys(next).length === 0);
  }

  if (done) {
    return (
      <div className="rounded-lg border border-sage/40 bg-sage-soft p-6" role="status">
        <h3 className="font-display text-2xl text-forest">This form is a demonstration</h3>
        <p className="mt-3 text-ink">
          Nothing was sent to the office, and no appointment was reserved. To request a visit, call{" "}
          <a className="font-medium text-forest" href={`tel:${practice.phoneTel}`}>
            {practice.phoneDisplay}
          </a>{" "}
          Monday through Friday.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-4">
      <p className="text-sm text-muted">
        Demonstration only. Submitting this form does not contact Dr. Masera’s office or hold a time.
      </p>
      <Field label="Name" name="name" error={errors.name} autoComplete="name" />
      <Field label="Phone" name="phone" error={errors.phone} autoComplete="tel" type="tel" />
      <Field label="Email" name="email" error={errors.email} autoComplete="email" type="email" />
      <div>
        <label className="text-sm font-medium" htmlFor="reason">
          What would you like to discuss?
        </label>
        <select
          id="reason"
          name="reason"
          defaultValue=""
          className="mt-1 w-full min-h-12 rounded-md border border-line bg-paper px-3"
          aria-invalid={Boolean(errors.reason)}
          aria-describedby={errors.reason ? "reason-error" : undefined}
        >
          <option value="" disabled>
            Select one
          </option>
          {reasons.map((item) => (
            <option key={item}>{item}</option>
          ))}
        </select>
        {errors.reason ? (
          <p id="reason-error" className="mt-1 text-sm text-danger">
            {errors.reason}
          </p>
        ) : null}
      </div>
      <div>
        <label className="text-sm font-medium" htmlFor="note">
          Anything we should know? <span className="font-normal text-muted">(optional)</span>
        </label>
        <textarea id="note" name="note" rows={4} className="mt-1 w-full rounded-md border border-line bg-paper px-3 py-3" />
      </div>
      <button
        type="submit"
        className="min-h-12 rounded-full bg-forest px-6 font-medium text-paper hover:bg-ink"
      >
        Preview request
      </button>
    </form>
  );
}

function Field({
  label,
  name,
  error,
  type = "text",
  autoComplete,
}: {
  label: string;
  name: string;
  error?: string;
  type?: string;
  autoComplete?: string;
}) {
  const errorId = `${name}-error`;
  return (
    <div>
      <label className="text-sm font-medium" htmlFor={name}>
        {label}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        autoComplete={autoComplete}
        aria-invalid={Boolean(error)}
        aria-describedby={error ? errorId : undefined}
        className="mt-1 w-full min-h-12 rounded-md border border-line bg-paper px-3"
      />
      {error ? (
        <p id={errorId} className="mt-1 text-sm text-danger">
          {error}
        </p>
      ) : null}
    </div>
  );
}
