import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, Phone, X } from "lucide-react";
import { useEffect, useState } from "react";
import { practice } from "@/lib/practice";

const links = [
  { to: "/", label: "Home" },
  { to: "/services", label: "Care" },
  { to: "/practice", label: "The Practice" },
  { to: "/patients", label: "Patients" },
  { to: "/contact", label: "Contact" },
] as const;

function Mark({ light = false }: { light?: boolean }) {
  return (
    <Link to="/" className="group flex items-center gap-3 no-underline">
      <span
        className={`grid size-11 place-items-center rounded-full border text-sm font-display ${
          light
            ? "border-paper/40 text-paper"
            : "border-forest/20 bg-paper text-forest"
        }`}
        aria-hidden
      >
        MM
      </span>
      <span className="leading-tight">
        <span className={`block font-display text-lg ${light ? "text-paper" : "text-ink"}`}>
          Michael D. Masera
        </span>
        <span className={`block text-xs tracking-wide ${light ? "text-paper/75" : "text-muted"}`}>
          DDS · Family & Cosmetic Dentistry
        </span>
      </span>
    </Link>
  );
}

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <header className="sticky top-0 z-40 border-b border-line/80 bg-ivory/90 backdrop-blur-md">
      <div className="bg-forest text-paper">
        <div className="container-page flex items-center justify-between gap-4 py-2 text-sm">
          <p className="truncate">Meyerland · Houston · {practice.hours}</p>
          <a className="inline-flex min-h-11 items-center gap-2 font-medium" href={`tel:${practice.phoneTel}`}>
            <Phone className="size-4" aria-hidden />
            {practice.phoneDisplay}
          </a>
        </div>
      </div>
      <div className="container-page flex items-center justify-between gap-4 py-3">
        <Mark />
        <nav className="hidden items-center gap-7 lg:flex" aria-label="Primary">
          {links.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="text-sm font-medium text-ink/80 no-underline hover:text-forest data-[status=active]:text-forest"
              activeOptions={{ exact: item.to === "/" }}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Link
            to="/contact"
            className="hidden min-h-11 items-center rounded-full bg-forest px-5 text-sm font-medium text-paper no-underline hover:bg-ink sm:inline-flex"
          >
            Request an Appointment
          </Link>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-full border border-line bg-paper lg:hidden"
            aria-expanded={open}
            aria-controls="mobile-nav"
            onClick={() => setOpen((v) => !v)}
          >
            <span className="sr-only">{open ? "Close menu" : "Open menu"}</span>
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>
      {open ? (
        <nav id="mobile-nav" className="border-t border-line bg-paper lg:hidden" aria-label="Mobile">
          <ul className="container-page flex flex-col py-2">
            {links.map((item) => (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className="flex min-h-12 items-center border-b border-line text-base no-underline"
                >
                  {item.label}
                </Link>
              </li>
            ))}
            <li className="py-3">
              <Link
                to="/contact"
                className="flex min-h-12 items-center justify-center rounded-full bg-forest text-paper no-underline"
              >
                Request an Appointment
              </Link>
            </li>
          </ul>
        </nav>
      ) : null}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="bg-forest text-paper">
      <div className="container-page grid gap-10 py-14 md:grid-cols-12">
        <div className="md:col-span-5">
          <Mark light />
          <p className="mt-5 max-w-sm text-paper/80">
            Family and cosmetic dentistry on Hillcroft Street, caring for Meyerland and southwest Houston.
          </p>
        </div>
        <div className="md:col-span-3">
          <p className="eyebrow text-sage-soft">Visit</p>
          <address className="mt-3 not-italic text-paper/85">
            {practice.addressLines.map((line) => (
              <span key={line} className="block">
                {line}
              </span>
            ))}
            <span className="mt-2 block text-sm text-paper/70">{practice.addressNote}</span>
          </address>
          <a className="mt-3 inline-flex min-h-11 items-center text-paper underline-offset-4 hover:underline" href={practice.mapsUrl}>
            Directions
          </a>
        </div>
        <div className="md:col-span-2">
          <p className="eyebrow text-sage-soft">Explore</p>
          <ul className="mt-3 space-y-2">
            {links.map((item) => (
              <li key={item.to}>
                <Link to={item.to} className="text-paper/85 no-underline hover:text-paper">
                  {item.label}
                </Link>
              </li>
            ))}
            <li>
              <Link to="/privacy" className="text-paper/85 no-underline hover:text-paper">
                Privacy note
              </Link>
            </li>
          </ul>
        </div>
        <div className="md:col-span-2">
          <p className="eyebrow text-sage-soft">Call</p>
          <a className="mt-3 block font-display text-2xl text-paper no-underline" href={`tel:${practice.phoneTel}`}>
            {practice.phoneDisplay}
          </a>
          <p className="mt-2 text-sm text-paper/70">Fax {practice.faxDisplay}</p>
          <a className="mt-3 inline-flex min-h-11 items-center text-paper/85 underline-offset-4 hover:underline" href={practice.facebook}>
            Facebook
          </a>
        </div>
      </div>
      <div className="border-t border-paper/15">
        <div className="container-page flex flex-col gap-2 py-5 text-sm text-paper/65 sm:flex-row sm:justify-between">
          <p>© {new Date().getFullYear()} Michael D. Masera, D.D.S.</p>
          <p>Redesign concept. The appointment form does not contact the office.</p>
        </div>
      </div>
    </footer>
  );
}

export function StickyCall() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-paper/95 p-2 backdrop-blur md:hidden">
      <div className="grid grid-cols-2 gap-2">
        <a
          className="flex min-h-12 items-center justify-center gap-2 rounded-full border border-forest text-sm font-medium text-forest no-underline"
          href={`tel:${practice.phoneTel}`}
        >
          <Phone className="size-4" aria-hidden />
          Call
        </a>
        <Link
          to="/contact"
          className="flex min-h-12 items-center justify-center rounded-full bg-forest text-sm font-medium text-paper no-underline"
        >
          Request visit
        </Link>
      </div>
    </div>
  );
}

export function PageIntro({
  eyebrow,
  title,
  lede,
}: {
  eyebrow: string;
  title: string;
  lede: string;
}) {
  return (
    <header className="border-b border-line bg-paper">
      <div className="container-page py-14 md:py-20">
        <p className="eyebrow">{eyebrow}</p>
        <h1 className="mt-3 max-w-3xl text-4xl text-forest md:text-6xl">{title}</h1>
        <p className="mt-5 max-w-2xl text-lg text-muted">{lede}</p>
      </div>
    </header>
  );
}
